package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import android.view.View.OnClickListener;
import il2cpp.typefaces.*;

public class Menu
{
	protected int WIDTH,HEIGHT;
    
	public Typeface google(Context yes) {return Typeface.createFromAsset(yes.getAssets(), "Font.ttf");}
	
	protected Context context;
	protected FrameLayout _parentBox;
	protected LinearLayout __page;
	protected ScrollView __scroll;
	
	public ArrayList<PageButton> _pagebuttons = new ArrayList<>();
	public ArrayList<LinearLayout> __pages = new ArrayList<>();
	
	public ImageView _icon;
	public TextView __pagetitle;
	public ImageView __pagesrc;
	boolean _isShow = false;
	public BottomLine lineOpen;

	
	
	LinearLayout menulayout,leftpanel,_pages,rightpanel,_scroll;
TextView name,_pagetitle;

 
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	protected void init(Context context) {
		
		this.context = context;
		
		_parentBox = new FrameLayout(context);

		_parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0,//initialX
			0,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showMenu() {
		_isShow = true;
		_parentBox.removeAllViews();
		_parentBox.addView(menulayout);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));															 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f);
		scaleDown.setDuration(350);
		scaleDown.start();
	}

	public void hideMenu() {
		_isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
			public void run() {
				_parentBox.removeAllViews();
				_parentBox.addView(_icon, dpi(50), dpi(50));
				Utils.anim(_icon, 200);
			}
		}, 350);
	}
	
	public void newPage(final String nm, final String src) {
		LinearLayout _page = new LinearLayout(context);
		PageButton _butt = new PageButton(context, nm, src);
		final int pageid = __pages.size();
		__page.setOrientation(LinearLayout.VERTICAL);
		_page.setOrientation(LinearLayout.VERTICAL);
		__page.addView(_page, -1, -1);
		_page.setVisibility(View.GONE);
		__pages.add(_page);
		_butt.callback = new PageButton.Callback() {
			public void onClick() {
				__pagetitle.setText(nm);
				Utils.SetAssets(context, __pagesrc, src);
				showPage(pageid);
			}
		};
		
		_pagebuttons.add(_butt);
		_pages.addView(_butt);
	}
	
	public void showPage(final int id) {
		for (PageButton pg: _pagebuttons) {
			pg.hide();
		}
		for (LinearLayout layout: __pages) {
			layout.setVisibility(View.GONE);
		}
		__pages.get(id).setVisibility(View.VISIBLE);
		_pagebuttons.get(id).show();
		Utils.anim(__pages.get(id), 400);
	}
	
	public Menu(Context context)
	{
		init(context);
		
		_icon = new ImageView(context);
		Utils.SetAssets(context, _icon, "icon.png");
		
		menulayout = new LinearLayout(context);
				{
					menulayout.setOrientation(0);
					menulayout.setPadding(5, 5, 5, 5);
					menulayout.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					menulayout.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(800, 440, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					menulayout.setLayoutParams(lp);
				}

		leftpanel = new LinearLayout(context);
				{
					leftpanel.setOrientation(1);
					leftpanel.setPadding(5, 5, 5, 5);
					leftpanel.setGravity(1);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-14606047);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					leftpanel.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(214, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					leftpanel.setLayoutParams(lp);
				}
menulayout.addView(leftpanel);

		name = new TextView(context);
				{
					name.setText("KORVUSCLIENT");
					name.setPadding(5, 5, 5, 5);
					name.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					name.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					name.setLayoutParams(lp);
					name.setTextColor(-1);
					name.setTextSize(13.0f);
					name.setTypeface(Utils.font(context));
				}
leftpanel.addView(name);

		_pages = new LinearLayout(context);
				{
					_pages.setOrientation(1);
					_pages.setPadding(5, 5, 5, 5);
					_pages.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_pages.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_pages.setLayoutParams(lp);
				}
leftpanel.addView(_pages);

		rightpanel = new LinearLayout(context);
				{
					rightpanel.setOrientation(1);
					rightpanel.setPadding(5, 5, 5, 5);
					rightpanel.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-13619152);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					rightpanel.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					rightpanel.setLayoutParams(lp);
				}
menulayout.addView(rightpanel);

		_pagetitle = new TextView(context);
				{
					_pagetitle.setText("TextView");
					_pagetitle.setPadding(5, 5, 5, 5);
					_pagetitle.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					_pagetitle.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_pagetitle.setLayoutParams(lp);
					_pagetitle.setTextColor(-1);
					_pagetitle.setTextSize(13.0f);
					_pagetitle.setTypeface(Utils.font(context));
				}
rightpanel.addView(_pagetitle);

		_scroll = new LinearLayout(context);
				{
					_scroll.setOrientation(1);
					_scroll.setPadding(5, 5, 5, 5);
					_scroll.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_scroll.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_scroll.setLayoutParams(lp);
				}
rightpanel.addView(_scroll);
LinearLayout _close = new LinearLayout(context);

LinearLayout _underpages = new LinearLayout(context);

ImageView _pagesrc = new ImageView(context);
		
		__pagetitle = _pagetitle;
		__pagesrc = _pagesrc;
		
		_close.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				hideMenu();
			}
		});
		
		__scroll = new ScrollView(context);
		__scroll.setFillViewport(true);
		
		__page = new LinearLayout(context);
		__page.setOrientation(LinearLayout.VERTICAL);
		
		__scroll.addView(__page, -1, -1);
		_scroll.addView(__scroll, -1, -1);
		
		lineOpen = new BottomLine(context);
		lineOpen.setCallback(new BottomLine.Callback() {
				public void onSwipe() {
					if (_isShow) {
						hideMenu();
					} else {
						showMenu();
					}
				}
			});
		wmManager.addView(_parentBox, wmParams);
	}
	
	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!_isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}
